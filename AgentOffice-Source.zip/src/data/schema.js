export const STATUSES=['Backlog','In progress','Done'];
export function validateOffice(members,zones){
 if(!Array.isArray(members)||!Array.isArray(zones))throw Error('Invalid arrays');
 for(const list of [members,zones]){
  if(new Set(list.map(x=>x.id)).size!==list.length)throw Error('Duplicate ID');
  for(const x of list)if(!x.id||typeof x.name!=='string')throw Error('Invalid identity');
 }
 for(const z of zones){const b=z.bounds;if(!b||!['x','z','width','depth'].every(k=>Number.isFinite(b[k]))||b.width<=0||b.depth<=0||!['teal','blue','red'].includes(z.color))throw Error('Invalid zone')}
 for(const m of members){const z=zones.find(z=>z.id===m.zoneId),d=m.desk;
 if(!z||!d||!Number.isFinite(d.x)||!Number.isFinite(d.z)||Math.abs(d.x-z.bounds.x)>z.bounds.width/2||Math.abs(d.z-z.bounds.z)>z.bounds.depth/2)throw Error('Invalid desk')}
 return true;
}
export function memberState(tasks,id){return tasks.some(t=>t.owner===id&&t.status==='In progress')?'working':'idle'}
