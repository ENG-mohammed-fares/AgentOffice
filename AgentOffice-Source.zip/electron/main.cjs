'use strict';
const { app, BrowserWindow, ipcMain, shell, Menu } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const { autoUpdater } = require('electron-updater');

let mainWindow;
let checking = false;
let state = { state: 'idle', message: 'Ready to check', version: app.getVersion(), percent: 0 };

// Default: updates can be installed on the next ordinary exit or via explicit restart.
autoUpdater.autoDownload = true;
autoUpdater.autoInstallOnAppQuit = true;
autoUpdater.allowPrerelease = false;

const updatesConfigured = () => app.isPackaged && fs.existsSync(path.join(process.resourcesPath, 'app-update.yml'));
function notify(patch) {
  state = { ...state, ...patch };
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('agentoffice:update-status', state);
  }
}
function checkUpdates() {
  if (!app.isPackaged) {
    notify({ state: 'development', message: 'Update checking works in installed releases, not development.' });
    return Promise.resolve(state);
  }
  if (!updatesConfigured()) {
    notify({ state: 'unconfigured', message: 'This build has no GitHub update feed. Publish through GitHub Actions.' });
    return Promise.resolve(state);
  }
  if (checking) return Promise.resolve(state);
  checking = true;
  notify({ state: 'checking', message: 'Checking for updates…', percent: 0 });
  return autoUpdater.checkForUpdates()
    .catch(err => {
      notify({ state: 'error', message: String(err.message || err).slice(0, 220) });
      return state;
    })
    .finally(() => { checking = false; });
}

autoUpdater.on('checking-for-update', () => notify({ state: 'checking', message: 'Checking GitHub Releases…' }));
autoUpdater.on('update-available', info => notify({ state: 'available', message: `Version ${info.version} available. Downloading…`, newVersion: info.version }));
autoUpdater.on('update-not-available', () => notify({ state: 'current', message: `You have the latest version (${app.getVersion()}).` }));
autoUpdater.on('download-progress', info => notify({ state: 'downloading', percent: Math.round(info.percent), message: `Downloading update: ${Math.round(info.percent)}%` }));
autoUpdater.on('update-downloaded', info => notify({ state: 'ready', percent: 100, newVersion: info.version, message: `Version ${info.version} is ready. Restart to install.` }));
autoUpdater.on('error', err => notify({ state: 'error', message: String(err.message || err).slice(0, 220) }));

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440, height: 900, minWidth: 960, minHeight: 620,
    title: 'AgentOffice', backgroundColor: '#0a101b',
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true
    }
  });
  Menu.setApplicationMenu(null);
  mainWindow.once('ready-to-show', () => mainWindow.show());
  const devUrl = !app.isPackaged && process.env.AGENTOFFICE_DEV_URL;
  if (devUrl) mainWindow.loadURL(devUrl);
  else mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://')) shell.openExternal(url).catch(() => {});
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    const allowedDev = Boolean(devUrl && url.startsWith(devUrl));
    const allowedLocal = !devUrl && url.startsWith('file://');
    if (!allowedDev && !allowedLocal) event.preventDefault();
  });
  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(() => {
  app.setAppUserModelId('com.agentoffice.desktop');
  ipcMain.handle('agentoffice:version', () => ({ version: app.getVersion(), configured: updatesConfigured(), packaged: app.isPackaged }));
  ipcMain.handle('agentoffice:update-status', () => state);
  ipcMain.handle('agentoffice:check-updates', () => checkUpdates().then(() => state));
  ipcMain.handle('agentoffice:install-update', () => {
    if (state.state !== 'ready' || !updatesConfigured()) return false;
    setImmediate(() => autoUpdater.quitAndInstall(false, true));
    return true;
  });
  createWindow();
  if (updatesConfigured()) {
    setTimeout(() => checkUpdates().catch(() => {}), 8000);
    const interval = setInterval(() => checkUpdates().catch(() => {}), 4 * 60 * 60 * 1000);
    interval.unref?.();
  } else if (app.isPackaged) {
    notify({ state: 'unconfigured', message: 'GitHub updates are not configured for this local build.' });
  }
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
