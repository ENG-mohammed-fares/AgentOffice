# Virtual Office interface

The post-login office uses the existing Vanilla JS / Vite / Three.js foundation.
Seven generic identities and three zones are defined in src/data. The scene
builds primitive furniture with InstancedMesh batching and one shadow light.
Room and avatar objects expose bundled GLB replacement hooks. No external
models or runtime downloads are used.

Use the zone buttons or keys 1–3, M for the orthographic map, and Escape to reset.
The member list is the accessible alternative to picking in the canvas.
Select a member for tasks and event history. Add a task and change its status
to In progress to animate typing. Demo activity sends walking, talking and task
events. Its badge is always visible and it can be paused. Agents are not connected.

Data is persisted per user under agentoffice:v2 keys. Existing v1.3 workspace
data is read without deleting it. Only task owners matching current member IDs
are imported. Sound requires a click to unlock WebAudio. Read aloud uses an
installed voice matching the selected language and remains silent if none exists.

Adaptive quality drops resolution and disables shadows after slow sampling.
60 FPS is a target, not a measured device guarantee. Profile on target laptops.
CSS2D labels use approximate screen-space overlap suppression. Characters and
furniture are intentionally procedural low-poly assets.

The bundled fonts are extracted from the unchanged sign-in document, which embeds
their Noto/SIL license. Copies retain their embedded font license/name tables.

Run npm install then npm run dev. Build the installer with npm run package:win.
Run node --test scripts/office.test.mjs scripts/identity.test.cjs.
Windows CI also exercises sign-in, task creation, selection, map switching
and captures qa/office-map.png and qa/office-3d.png.
