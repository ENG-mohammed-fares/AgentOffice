# AgentOffice — Desktop prototype

A 3D virtual software company demo with seven themed rooms, placeholder 3D employees, camera controls, and desktop auto-update UI. **No real AI agents are connected yet.**

Desktop technology: Electron + Vite + Three.js. Version **1.1.0**.

## Develop locally

```bash
npm install
npm run dev
```

## Build Windows installer

```bash
npm install
npm run package:win
```

The installer appears at `release/AgentOffice-Setup-1.1.0-x64.exe` if building succeeds. This repo targets Windows x64.

## GitHub Releases auto-update

The repository at `ENG-mohammed-fares/AgentOffice` includes a GitHub Actions workflow in `.github/workflows/windows-release.yml` that extracts an uploaded `AgentOffice-Source.zip` file in the repo root, installs dependencies, builds a Windows NSIS installer, and publishes it to GitHub Releases via `electron-builder`.

**Important:** the ZIP is source code, not a compiled EXE. The first installer is only available **after** a successful Actions run. The repo must be Public for unauthenticated auto-updates. Future updates require raising the package version, uploading a matching new source ZIP, and a successful GitHub Release. All update assets, including `latest.yml`, are published by the builder. Do not embed any token in the app.

`electron-updater` checks shortly after startup and every four hours, and supports manual checking via the interface. Users can restart to install downloaded updates. This flow must be tested in a real installed Windows environment.

GitHub's free Windows Actions runners can create installers for public projects, subject to usage terms and account restrictions. Unsigned installers can trigger Windows SmartScreen warnings.

## Current limitations

The 3D environment is a prototype. Employee avatars are geometric placeholders, and task statuses are simulated. Photorealistic 3D models, real AI-agent backends, and local ML model execution are not yet implemented.

See `SETUP-AR.md` for Arabic instructions.
