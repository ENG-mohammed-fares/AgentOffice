import screen from './auth-screen.html?raw';
import {mountLoadingIntro} from './loading-intro.js';

export function mountAuth({onAuthenticated}) {
  let entered=false;
  const frame = document.createElement('iframe');
  frame.title = 'AgentOffice — تسجيل الدخول / Sign in';
  frame.style.cssText = 'display:block;width:100%;height:100dvh;border:0;background:#181a19';
  frame.addEventListener('load', () => {
    frame.contentWindow.connectAgentOffice({
      auth: window.agentOfficeDesktop?.auth,
      enter: user => {
        if(entered||!frame.isConnected)return;
        entered=true;
        mountLoadingIntro({onComplete:()=>onAuthenticated(user)});
      }
    });
  }, {once:true});
  frame.srcdoc = screen;
  document.querySelector('#app').replaceChildren(frame);
}
