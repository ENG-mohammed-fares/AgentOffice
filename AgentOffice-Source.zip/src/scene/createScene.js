import * as T from 'three';
import {CSS2DRenderer,CSS2DObject} from 'three/addons/renderers/CSS2DRenderer.js';
import {createCameraRig} from './cameraRig.js';
import {buildOffice,PALETTE} from './officeRoom.js';
import {createAvatars} from './avatars.js';
import {localName} from '../data/labels.js';
export function createScene(container,{store,lang,labels,onSelect}){
 const renderer=new T.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
 renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.5));renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
 renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;
 renderer.domElement.style.cssText='display:block;width:100%;height:100%';
 container.append(renderer.domElement);
 const overlay=new CSS2DRenderer();overlay.domElement.className='scene-labels';container.append(overlay.domElement);
 const scene=new T.Scene();scene.background=new T.Color(PALETTE.white);
 scene.add(new T.HemisphereLight(PALETTE.white,PALETTE.wood,2));
 const sun=new T.DirectionalLight(PALETTE.white,3);sun.position.set(4,18,-5);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);
 Object.assign(sun.shadow.camera,{left:-20,right:20,top:20,bottom:-20,near:.5,far:60});sun.shadow.bias=-.0006;sun.shadow.normalBias=.04;scene.add(sun);
 const state=store.get(),room=buildOffice(scene,state.members,state.zones);
 const avatars=createAvatars(scene,state.members,{lang,labels});
 for(const z of state.zones){
  const el=document.createElement('div');el.className='zone-label';el.textContent=localName(z,lang);
  const label=new CSS2DObject(el);label.position.set(z.bounds.x,.12,z.bounds.z-z.bounds.depth/2+.8);scene.add(label);
 }
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const rig=createCameraRig(renderer.domElement,reduced),ray=new T.Raycaster(),pointer=new T.Vector2();
 let down=null;
 const pick=e=>{const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,rig.camera);return ray.intersectObjects(avatars.picks).find(hit=>hit.object.visible&&hit.object.parent.visible)?.object.userData.memberId};
 const hover=e=>avatars.hover(pick(e));const press=e=>{down={x:e.clientX,y:e.clientY}};
 const release=e=>{if(down&&Math.hypot(e.clientX-down.x,e.clientY-down.y)<5){const id=pick(e);if(id)onSelect(id)}down=null};
 renderer.domElement.addEventListener('pointermove',hover);renderer.domElement.addEventListener('pointerdown',press);renderer.domElement.addEventListener('pointerup',release);
 const resize=()=>{const w=container.clientWidth||1,h=container.clientHeight||1;renderer.setSize(w,h,false);overlay.setSize(w,h);rig.resize(w,h)};
 const observer=new ResizeObserver(resize);observer.observe(container);resize();
 let previous=performance.now(),samples=0,total=0,lastSelection='',lastMode='',frame=0,disposed=false;
 const loop=now=>{
  if(disposed)return;frame=requestAnimationFrame(loop);
  if(document.hidden){previous=now;return}
  const dt=Math.min((now-previous)/1000,.1);previous=now;const s=store.get();
  if(s.cameraMode!==lastMode){rig.setMode(s.cameraMode);lastMode=s.cameraMode}
  const selection=s.selectedMemberId||s.selectedZoneId||'whole';
  if(selection!==lastSelection){const m=s.members.find(m=>m.id===s.selectedMemberId),z=s.zones.find(z=>z.id===s.selectedZoneId);rig.focus(m?m.desk:z?z.bounds:{x:0,z:0},m?false:z?true:'whole');lastSelection=selection}
  rig.update(now);avatars.update(now,dt,s,rig.camera,s.cameraMode==='map',reduced);
  renderer.render(scene,rig.camera);overlay.render(scene,rig.camera);
  renderer.domElement.dataset.view=rig.camera.isOrthographicCamera?'map':'3d';
  if(++samples>150){const average=total/samples;if(average>.027){renderer.setPixelRatio(Math.max(.75,renderer.getPixelRatio()-.25));renderer.shadowMap.enabled=false;resize()}else if(average<.017&&renderer.getPixelRatio()<Math.min(devicePixelRatio,1.5)){renderer.setPixelRatio(Math.min(1.5,renderer.getPixelRatio()+.125));resize()}samples=0;total=0}else total+=dt;
 };
 frame=requestAnimationFrame(loop);
 return {room,event:e=>avatars.event(e),dispose(){
  disposed=true;cancelAnimationFrame(frame);observer.disconnect();rig.dispose();
  renderer.domElement.removeEventListener('pointermove',hover);renderer.domElement.removeEventListener('pointerdown',press);renderer.domElement.removeEventListener('pointerup',release);
  const resources=new Set();scene.traverse(o=>{if(o.geometry)resources.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:o.material?[o.material]:[])resources.add(m);if(o.isCSS2DObject)o.element.remove()});resources.forEach(r=>r.dispose());sun.shadow.dispose();renderer.dispose();renderer.forceContextLoss();container.replaceChildren();
 }};
}
