'use strict';
// A downloaded update must never interrupt an authenticated workspace or an auth flow.
function mayAutoRestart({ready,configured,installing,authSafe,idleSeconds,readySeconds}) {
  return ready === true && configured === true && installing === false &&
    authSafe === true && Number.isFinite(idleSeconds) && idleSeconds >= 120 &&
    Number.isFinite(readySeconds) && readySeconds >= 15;
}
module.exports = { mayAutoRestart };
