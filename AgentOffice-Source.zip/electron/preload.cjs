'use strict';
const { contextBridge, ipcRenderer } = require('electron');

// Only expose narrowly scoped updater commands to the 3D renderer.
contextBridge.exposeInMainWorld('agentOfficeDesktop', {
  version: () => ipcRenderer.invoke('agentoffice:version'),
  updateStatus: () => ipcRenderer.invoke('agentoffice:update-status'),
  checkUpdates: () => ipcRenderer.invoke('agentoffice:check-updates'),
  installUpdate: () => ipcRenderer.invoke('agentoffice:install-update'),
  onUpdateStatus: callback => {
    if (typeof callback !== 'function') return () => {};
    const handler = (_event, status) => callback(status);
    ipcRenderer.on('agentoffice:update-status', handler);
    return () => ipcRenderer.removeListener('agentoffice:update-status', handler);
  }
});
