'use strict';
// A small LOCAL-ONLY account store for the AgentOffice desktop prototype.
// This is not an internet identity system: no email verification, recovery, or cloud sync.
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { app } = require('electron');
const scrypt = promisify(crypto.scrypt);
let session = null;
const attempts = new Map();
const FILE = () => path.join(app.getPath('userData'), 'local-accounts.json');

function normalEmail(v) { return typeof v === 'string' ? v.trim().toLowerCase() : ''; }
function validEmail(v) { return v.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
function safeUser(account) { return { id: account.id, name: account.name, email: account.email, guest: false }; }
function passwordRule(password) { return typeof password === 'string' && password.length >= 10 && password.length <= 1024; }
async function readAccounts() {
  try {
    const data = JSON.parse(await fs.readFile(FILE(), 'utf8'));
    if (!data || !Array.isArray(data.accounts)) throw new Error('Local account database is invalid.');
    return data;
  } catch (e) {
    if (e.code === 'ENOENT') return { version: 1, accounts: [] };
    throw e;
  }
}
async function saveAccounts(data) {
  const file = FILE();
  await fs.mkdir(path.dirname(file), { recursive: true });
  const temp = file + '.' + crypto.randomBytes(5).toString('hex') + '.tmp';
  try { await fs.writeFile(temp, JSON.stringify(data, null, 2), { encoding: 'utf8', mode: 0o600, flag: 'wx' }); await fs.rename(temp, file); }
  finally { await fs.rm(temp, { force: true }).catch(() => {}); }
}
function blockCheck(email) {
  const record = attempts.get(email);
  if (!record) return;
  if (record.until > Date.now()) throw new Error('Too many attempts. Try again in a few minutes.');
  if (record.until) attempts.delete(email);
}
function recordFailure(email) {
  const state = attempts.get(email) || { count: 0, until: 0 };
  state.count += 1;
  if (state.count >= 7) { state.count = 0; state.until = Date.now() + 120000; }
  attempts.set(email, state);
}
async function signUp(payload) {
  const name = String(payload?.name || '').trim();
  const email = normalEmail(payload?.email);
  const password = payload?.password;
  if (name.length < 2 || name.length > 80) throw new Error('Name must be between 2 and 80 characters.');
  if (!validEmail(email)) throw new Error('Enter a valid email address.');
  if (!passwordRule(password)) throw new Error('Password must contain between 10 and 1024 characters.');
  const db = await readAccounts();
  if (db.accounts.some(a => a.email === email)) throw new Error('An account with this email already exists on this computer.');
  const salt = crypto.randomBytes(24).toString('hex');
  const digest = await scrypt(password, salt, 64, { N: 16384, r: 8, p: 1 });
  const account = { id: crypto.randomUUID(), email, name, salt, digest: digest.toString('hex'), createdAt: new Date().toISOString() };
  db.accounts.push(account);
  await saveAccounts(db);
  session = safeUser(account);
  return session;
}
async function signIn(payload) {
  const email = normalEmail(payload?.email);
  const password = payload?.password;
  if (!validEmail(email) || !passwordRule(password)) throw new Error('Incorrect email or password.');
  blockCheck(email);
  const db = await readAccounts();
  const account = db.accounts.find(a => a.email === email);
  // Run scrypt even when no user is found to reduce account-enumeration timing.
  const salt = account?.salt || '000000000000000000000000000000000000000000000000';
  const expected = account?.digest || '00'.repeat(64);
  const actual = await scrypt(password, salt, 64, { N: 16384, r: 8, p: 1 });
  const candidate = Buffer.from(expected, 'hex');
  if (!account || candidate.length !== actual.length || !crypto.timingSafeEqual(candidate, actual)) {
    recordFailure(email);
    throw new Error('Incorrect email or password.');
  }
  attempts.delete(email);
  session = safeUser(account);
  return session;
}
function registerAuth(ipcMain) {
  ipcMain.handle('agentoffice:auth:current', () => session);
  ipcMain.handle('agentoffice:auth:signup', (_event, payload) => signUp(payload));
  ipcMain.handle('agentoffice:auth:signin', (_event, payload) => signIn(payload));
  ipcMain.handle('agentoffice:auth:guest', () => { session = { id: 'guest', name: 'Guest', guest: true, email: null }; return session; });
  ipcMain.handle('agentoffice:auth:logout', () => { session = null; return true; });
}
module.exports = { registerAuth };
