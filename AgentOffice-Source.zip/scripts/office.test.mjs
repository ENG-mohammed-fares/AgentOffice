import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {validateOffice,memberState} from '../src/data/schema.js';
import {createOfficeStore} from '../src/store/officeStore.js';
import {createMockRuntime,createRuntime} from '../src/runtime/officeRuntime.js';
const members=JSON.parse(fs.readFileSync(new URL('../src/data/members.json',import.meta.url)));
const zones=JSON.parse(fs.readFileSync(new URL('../src/data/zones.json',import.meta.url)));
const storage=()=>{const map=new Map();return {getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,v),map}};
test('data validates uniqueness, zone links and desk bounds',()=>{
 assert.equal(validateOffice(members,zones),true);
 assert.throws(()=>validateOffice([...members,members[0]],zones));
 assert.throws(()=>validateOffice([{...members[0],zoneId:'missing'}],zones));
 assert.throws(()=>validateOffice([{...members[0],desk:{x:500,z:500}}],zones));
});
test('per-user tasks, preferences and character task states',()=>{
 const db=storage(),a=createOfficeStore({userId:'a',members,zones,storage:db});
 assert.equal(a.addTask(' ',members[0].id),false);
 assert.equal(a.addTask('Implement feature',members[0].id),true);
 a.updateTask(a.get().tasks[0].id,'In progress');assert.equal(memberState(a.get().tasks,members[0].id),'working');
 a.updateTask(a.get().tasks[0].id,'invalid');assert.equal(a.get().tasks[0].status,'In progress');
 a.toggleSetting('sound');
 const b=createOfficeStore({userId:'b',members,zones,storage:db});assert.equal(b.get().tasks.length,0);
 const restored=createOfficeStore({userId:'a',members,zones,storage:db});assert.equal(restored.get().tasks.length,1);assert.equal(restored.get().settings.sound,true);
});
test('corrupt storage and storage errors are recoverable',()=>{
 const db={getItem:()=>'{',setItem:()=>{throw Error('quota')}};
 const s=createOfficeStore({members,zones,storage:db});s.addTask('Test',members[0].id);assert.equal(s.storageFailed,true);
});
test('runtime dispatch, pause and teardown',()=>{
 const s=createOfficeStore({members,zones,storage:storage()});
 let tick,cleared=false;const r=createMockRuntime({store:s,setTimer:fn=>{tick=fn;return 3},clearTimer:id=>{assert.equal(id,3);cleared=true}});
 const seen=[];const off=r.subscribe(e=>seen.push(e));tick();assert.equal(seen[0].type,'member:move');assert.equal(seen[1].type,'announcement:new');
 s.toggleDemo();tick();assert.equal(seen.length,2);off();r.dispose();assert.ok(cleared);
 const bus=createRuntime();assert.throws(()=>bus.emit('unknown'));
});
