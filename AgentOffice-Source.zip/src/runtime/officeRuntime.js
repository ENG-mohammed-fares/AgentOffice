export function createRuntime(){
 const listeners=new Set();
 return {subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn)},
 emit(type,payload={}){if(!['member:status','member:move','announcement:new','task:updated'].includes(type))throw Error('Unknown runtime event');const event={...payload,type,at:Date.now()};listeners.forEach(fn=>fn(event));return event},
 dispose(){listeners.clear()}};
}
export function createMockRuntime({store,interval=12000,setTimer=setInterval,clearTimer=clearInterval}){
 const runtime=createRuntime();let index=0;
 const tick=()=>{
 const s=store.get();if(!s.demoRunning||!s.members.length)return;
 const m=s.members[index++%s.members.length],turn=index%3;
 if(turn===1)runtime.emit('member:move',{memberId:m.id,target:{x:7,z:-2},duration:9});
 if(turn===2)runtime.emit('member:status',{memberId:m.id,status:'talking',duration:5});
 const task=s.tasks.find(t=>t.owner===m.id);
 if(task&&turn===0)runtime.emit('task:updated',{taskId:task.id,status:task.status==='Backlog'?'In progress':task.status==='In progress'?'Done':'Backlog',memberId:m.id});
 runtime.emit('announcement:new',{memberId:m.id,messageKey:'event'});
 };
 const timer=setTimer(tick,interval),dispose=runtime.dispose;
 return {...runtime,tick,dispose(){clearTimer(timer);dispose()}};
}
