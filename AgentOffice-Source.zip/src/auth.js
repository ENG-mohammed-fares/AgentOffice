import './auth.css';
import {icon} from './icons.js';
import {mountStudio} from './studio.js';

/** Local Windows identity, separate from any future cloud authentication. */
export function mountAuth({onAuthenticated}){
  const root=document.querySelector('#app');
  const desktop=window.agentOfficeDesktop;
  let mode='signin',busy=false,scene=null;
  const safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const remembered=(()=>{try{return localStorage.getItem('agentoffice:last-email')||'';}catch{return '';}})();
  function render(){
    scene?.dispose();scene=null;
    const creating=mode==='signup';
    root.innerHTML=`<div class="auth-shell"><div class="auth-left"><div class="auth-top"><a href="#" id="brand-link" class="auth-logo"><img src="./icon.png" width="43" height="43" alt=""><span>AgentOffice<span class="auth-dot">.</span></span></a><span class="auth-edition">Desktop preview</span></div>
      <div class="auth-content"><div class="auth-greeting">${creating?'Get started':'Your workspace is ready'}</div><h1>${creating?'Create a workspace.':'Welcome back.'}</h1><p class="auth-description">${creating?'Set up a local account to explore your virtual software team.':'Sign in to plan work and explore your virtual AI office.'}</p>
        <div class="auth-tabs" role="tablist" aria-label="Account access"><button id="tab-signin" type="button" role="tab" aria-selected="${!creating}" class="auth-tab ${!creating?'is-active':''}">Sign in</button><button id="tab-signup" type="button" role="tab" aria-selected="${creating}" class="auth-tab ${creating?'is-active':''}">Create account</button></div>
        <form id="auth-form" novalidate>${creating?`<label class="auth-field"><span>Full name</span><div class="auth-input">${icon('user',19)}<input id="auth-name" name="name" maxlength="80" minlength="2" autocomplete="name" placeholder="Your name" required /></div></label>`:''}
          <label class="auth-field"><span>Email address</span><div class="auth-input">${icon('mail',19)}<input id="auth-email" name="email" type="email" inputmode="email" maxlength="254" autocomplete="email" value="${safe(remembered)}" placeholder="you@example.com" required /></div></label>
          <label class="auth-field"><span>Password</span><div class="auth-input">${icon('lock',19)}<input id="auth-password" name="password" type="password" autocomplete="${creating?'new-password':'current-password'}" minlength="10" maxlength="1024" placeholder="${creating?'At least 10 characters':'Your password'}" required /><button type="button" class="auth-visibility" data-toggle="auth-password" aria-label="Show password" aria-pressed="false">${icon('eye',19)}</button></div></label>
          ${creating?`<label class="auth-field"><span>Confirm password</span><div class="auth-input">${icon('lock',19)}<input id="auth-confirm" name="confirm" type="password" autocomplete="new-password" minlength="10" maxlength="1024" placeholder="Repeat your password" required /><button type="button" class="auth-visibility" data-toggle="auth-confirm" aria-label="Show password" aria-pressed="false">${icon('eye',19)}</button></div></label>`:''}
          ${creating?`<div class="auth-helper">${icon('shield',16)} Accounts are stored on this computer only.</div>`:`<label class="auth-remember"><input type="checkbox" id="remember-email" checked> Remember my email</label>`}
          <div class="auth-error" id="auth-error" role="alert" hidden></div><button class="auth-primary" id="auth-submit" type="submit">${creating?'Create workspace':'Sign in'}</button>
        </form><div class="auth-break"><span>Or explore first</span></div><button class="auth-guest" type="button" id="auth-guest">${icon('building',18)} Try the demo workspace</button><p class="auth-privacy">${desktop?'Local accounts only. No password recovery or cloud sync yet.':'The browser preview supports guest access. Install the Windows app to create a local account.'}</p>
      </div><div class="auth-bottom"><span>AgentOffice · 2026</span><span>Made for people who build.</span></div></div>
      <aside class="auth-right" aria-label="Product preview"><div class="auth-right-heading"><span class="auth-status-point"></span> An interactive office prototype <span class="auth-right-number">01 — 07</span></div><div class="auth-visual-copy"><span>A new way to manage work</span><h2>Your software team.<br><em>One place to build.</em></h2><p>Explore seven roles, plan real tasks, and shape the digital studio where your future AI agents will collaborate.</p></div><div class="auth-product-display"><div class="auth-preview-top">${icon('building',15)} The AgentOffice studio <span>Preview</span></div><div class="auth-live-scene" id="auth-scene"></div><div class="auth-preview-bottom"><div><span class="auth-preview-dot"></span> Real-time 3D view</div><span>Model preview</span></div></div><div class="auth-right-note">The 3D workspace works today. Autonomous AI agents are a future feature.</div></aside></div>`;
    bind();
    scene=mountStudio(document.querySelector('#auth-scene'),{full:false});
    requestAnimationFrame(()=>document.querySelector(creating?'#auth-name':'#auth-email')?.focus({preventScroll:true}));
  }
  function message(text){const target=document.querySelector('#auth-error');target.textContent=text||'';target.hidden=!text;}
  function busyState(next){busy=next;const b=document.querySelector('#auth-submit');if(b){b.disabled=next;b.textContent=next?'Working…':mode==='signup'?'Create workspace':'Sign in';}const g=document.querySelector('#auth-guest');if(g)g.disabled=next;}
  async function submit(form){
    const data=new FormData(form),creating=mode==='signup',name=String(data.get('name')||'').trim(),email=String(data.get('email')||'').trim().toLowerCase(),password=String(data.get('password')||'');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return message('Enter a valid email address.');
    if(creating&&name.length<2)return message('Please enter your full name.');
    if(password.length<10)return message('Password must contain at least 10 characters.');
    if(creating&&password!==String(data.get('confirm')||''))return message('Passwords do not match.');
    if(!desktop?.auth)return message('Local accounts are available in the installed Windows app. Select the demo workspace to preview in your browser.');
    message('');busyState(true);
    try {const result=creating?await desktop.auth.signUp({name,email,password}):await desktop.auth.signIn({email,password});try{if(creating||document.querySelector('#remember-email')?.checked)localStorage.setItem('agentoffice:last-email',email);else localStorage.removeItem('agentoffice:last-email');}catch{}
      scene?.dispose();scene=null;onAuthenticated(result);
    }catch(error){message(String(error?.message||'Something went wrong. Please try again.'));}finally{busyState(false);}
  }
  function bind(){document.querySelector('#brand-link')?.addEventListener('click',e=>e.preventDefault());document.querySelector('#tab-signin')?.addEventListener('click',()=>{if(!busy&&mode!=='signin'){mode='signin';render();}});document.querySelector('#tab-signup')?.addEventListener('click',()=>{if(!busy&&mode!=='signup'){mode='signup';render();}});document.querySelector('#auth-form')?.addEventListener('submit',e=>{e.preventDefault();submit(e.currentTarget);});
    document.querySelectorAll('[data-toggle]').forEach(button=>button.addEventListener('click',()=>{const input=document.getElementById(button.dataset.toggle);if(!input)return;input.type=input.type==='password'?'text':'password';button.setAttribute('aria-pressed',String(input.type==='text'));button.setAttribute('aria-label',input.type==='text'?'Hide password':'Show password');button.innerHTML=icon(input.type==='text'?'eyeOff':'eye',19);}));
    document.querySelector('#auth-guest')?.addEventListener('click',async()=>{if(busy)return;try{const user=desktop?.auth?await desktop.auth.guest():{id:'guest',name:'Guest',email:null,guest:true};scene?.dispose();scene=null;onAuthenticated(user);}catch(error){message(error?.message||'Unable to open demo.');}});
  }
  render();
}
