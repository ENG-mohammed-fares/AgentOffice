import {icon} from '../icons.js';
import {esc} from './util.js';
import {mountUpdates} from './updates.js';
import {createOfficeStore} from '../store/officeStore.js';
import {createScene} from '../scene/createScene.js';
import {mountToolbar} from '../ui/toolbar.js';
import {LABELS,localName} from '../data/labels.js';
import {STATUSES,memberState} from '../data/schema.js';
import {createMockRuntime} from '../runtime/officeRuntime.js';
import members from '../data/members.json';
import zones from '../data/zones.json';
export function mountApp(user,{onSignOut}){
 const root=document.querySelector('#app'),desktop=window.agentOfficeDesktop;
 let lang='en';try{lang=localStorage.getItem('agentoffice:auth-language')==='ar'?'ar':'en'}catch{}
 let cleanup=()=>{};
 function mount(){
 const l=LABELS[lang],name=m=>localName(m,lang);
 document.documentElement.dir=lang==='ar'?'rtl':'ltr';document.documentElement.lang=lang;
 const store=createOfficeStore({userId:user?.id||'guest',members,zones});
 root.innerHTML=`<div class="shell office-shell"><header class="topbar"><div class="shell-brand"><img src="./icon.png" alt="" width="34" height="34"><span>AgentOffice<span class="brand-period">.</span></span></div><span class="demo-badge">${l.demo}</span><div class="topbar-right"><button class="tb-btn" id="office-language">${l.language}</button><button class="icon-button" id="check-update" aria-label="${l.updates}">${icon('refresh',18)}</button><span class="rail-person"><strong>${esc(user?.guest?'Guest workspace':user?.name||l.account)}</strong><small>${l.account}</small></span><button class="icon-button" id="sign-out" aria-label="${l.logout}">${icon('logOut',18)}</button></div></header>
 <div class="office-controls" id="toolbar-host"></div><div class="office-layout"><main class="stage"><div id="scene-host" class="scene-host"></div><p class="loading-note" id="stage-note" role="status">${l.loading}</p><div class="scene-legend"><span class="legend-dot"></span>${l.office}<small>1–3 · M · Esc</small></div></main>
 <aside class="office-sidebar" aria-label="${l.team}"><section><h2>${l.team}</h2><div id="member-list"></div></section><section id="member-panel" hidden></section><section><h2>${l.sprint}</h2><form id="task-form"><label for="task-title">${l.title}</label><input id="task-title" maxlength="160" required><label for="task-owner">${l.owner}</label><select id="task-owner">${members.map(m=>`<option value="${esc(m.id)}">${esc(name(m))}</option>`).join('')}</select><button class="btn btn-primary">${l.add}</button></form><div id="task-list"></div></section></aside></div>
 <footer class="office-footer"><span id="ticker" role="status">${l.welcome}</span><span>${l.demo}</span></footer><div class="notification" id="notification" role="status" hidden></div><div id="update-toast" class="updater-banner" hidden></div></div>`;
 let timer,audio,scene=null,disposed=false,lastEvent=0;
 const toast=message=>{const el=root.querySelector('#notification');el.textContent=message;el.hidden=false;clearTimeout(timer);timer=setTimeout(()=>el.hidden=true,4000)};
 const notify=e=>{
  const s=store.get(),m=members.find(m=>m.id===e.memberId);
  const text=(m?name(m)+' · ':'')+l.event;
  if(e.type!=='announcement:new')return;
  root.querySelector('#ticker').textContent=text;
  if(s.settings.alerts)toast(text);
  if(s.settings.sound&&audio?.state==='running'){
   const oscillator=audio.createOscillator(),gain=audio.createGain();oscillator.frequency.value=660;gain.gain.setValueAtTime(.04,audio.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+.14);oscillator.connect(gain);gain.connect(audio.destination);oscillator.start();oscillator.stop(audio.currentTime+.15);
  }
  if(s.settings.readAloud&&'speechSynthesis'in window){
   const voice=speechSynthesis.getVoices().find(v=>v.lang.startsWith(lang));
   if(voice){speechSynthesis.cancel();const speech=new SpeechSynthesisUtterance(text);speech.voice=voice;speech.lang=voice.lang;speechSynthesis.speak(speech)}
  }
 };
 const unlock=()=>{if(store.get().settings.sound){try{audio??=new AudioContext();audio.resume().catch(()=>{})}catch{}}};
 root.addEventListener('click',unlock);
  const taskHTML=tasks=>tasks.length?tasks.map(t=>`<div class="task-row"><span>${esc(t.title)}</span><select data-task="${esc(t.id)}" aria-label="${esc(t.title)}">${STATUSES.map(v=>`<option value="${esc(v)}" ${v===t.status?'selected':''}>${esc(l[v])}</option>`).join('')}</select></div>`).join(''):`<p class="muted">${l.empty}</p>`;
 function render(){
  if(disposed)return;const s=store.get();
  root.querySelector('#member-list').innerHTML=members.map((m,i)=>`<button class="member-button" data-member="${esc(m.id)}" aria-pressed="${m.id===s.selectedMemberId}"><span class="avatar-initial">${i+1}</span><span>${esc(name(m))}<small>${l[memberState(s.tasks,m.id)]}</small></span><i class="status-dot"></i></button>`).join('');
  const m=members.find(m=>m.id===s.selectedMemberId),panel=root.querySelector('#member-panel');
  panel.hidden=!m;
  if(m){
   const events=s.events.filter(e=>e.memberId===m.id).slice(0,4);
   panel.dataset.lastActivity=events[0]?new Date(events[0].at).toISOString():'';
   panel.innerHTML=`<div class="panel-head"><h2>${esc(name(m))}</h2><button class="icon-button" id="close-panel" aria-label="${l.close}">×</button></div><p>${esc(lang==='ar'?m.descriptionAr:m.description)}</p><p class="muted">${l[memberState(s.tasks,m.id)]}</p><h3>${l.tasks}</h3>${taskHTML(s.tasks.filter(t=>t.owner===m.id))}<h3>${l.activity}</h3><ol>${events.map(e=>`<li><time>${new Date(e.at).toLocaleTimeString(lang,{hour:'2-digit',minute:'2-digit'})}</time> · ${l.event}</li>`).join('')}</ol><textarea disabled aria-label="${l.chat}" placeholder="${l.chat}"></textarea><small class="muted">${l.chat}</small>`;
  }
  root.querySelector('#task-list').innerHTML=taskHTML(s.tasks);
  const latest=s.announcements[0];if(latest&&latest.at!==lastEvent){lastEvent=latest.at;notify(latest)}
 }
 const off=store.subscribe(render);render();
 const selection=id=>{store.selectMember(id);root.querySelector('#member-panel').scrollIntoView({block:'nearest',behavior:'instant'})};
 try{scene=createScene(root.querySelector('#scene-host'),{store,lang,labels:l,onSelect:selection});root.querySelector('#stage-note').hidden=true}
 catch(error){console.error('Office WebGL initialization',error);root.querySelector('#stage-note').textContent=l.webgl}
 const disposeToolbar=mountToolbar(root.querySelector('#toolbar-host'),store,{lang,labels:l});
 const disposeUpdates=mountUpdates({desktop,button:root.querySelector('#check-update'),banner:root.querySelector('#update-toast'),showToast:toast});
 const runtime=createMockRuntime({store});
 const offRuntime=runtime.subscribe(e=>{if(e.type==='task:updated')store.updateTask(e.taskId,e.status);scene?.event(e);store.record(e)});
 const click=e=>{const member=e.target.closest('[data-member]');if(member)selection(member.dataset.member);if(e.target.closest('#close-panel')){store.selectMember(null);root.querySelector('[data-member]')?.focus()}};
 const change=e=>{if(e.target.dataset.task){store.updateTask(e.target.dataset.task,e.target.value);if(store.storageFailed)toast(l.storage)}};
 root.addEventListener('click',click);root.addEventListener('change',change);
 root.querySelector('#task-form').onsubmit=e=>{e.preventDefault();const input=root.querySelector('#task-title');if(!store.addTask(input.value,root.querySelector('#task-owner').value))return toast(l.invalid);input.value='';if(store.storageFailed)toast(l.storage);input.focus()};
 const keys=e=>{if(e.target.closest('input,select,textarea,button')||e.ctrlKey||e.altKey||e.metaKey)return;
 if(e.key.toLowerCase()==='m')store.setCameraMode(store.get().cameraMode==='map'?'3d':'map');
 if(e.key==='Escape'){store.selectMember(null);store.selectZone(null)}
 const n=Number(e.key);if(n>=1&&n<=zones.length){store.selectMember(null);store.selectZone(zones[n-1].id)}
 };
 window.addEventListener('keydown',keys);
 cleanup=()=>{disposed=true;clearTimeout(timer);runtime.dispose();offRuntime();off();disposeToolbar();disposeUpdates();scene?.dispose();audio?.close().catch(()=>{});if('speechSynthesis'in window)speechSynthesis.cancel();root.removeEventListener('click',click);root.removeEventListener('click',unlock);root.removeEventListener('change',change);window.removeEventListener('keydown',keys)};
 root.querySelector('#sign-out').onclick=()=>{cleanup();desktop?.auth?.logout?.().catch(()=>{});onSignOut()};
 root.querySelector('#office-language').onclick=()=>{cleanup();lang=lang==='ar'?'en':'ar';try{localStorage.setItem('agentoffice:auth-language',lang)}catch{}mount()};
 }
 mount();
 return()=>cleanup();
}
