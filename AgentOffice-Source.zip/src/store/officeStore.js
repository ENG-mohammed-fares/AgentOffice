import {createStore} from './store.js';
import {STATUSES,validateOffice} from '../data/schema.js';
export function createOfficeStore({userId='guest',members=[],zones=[],storage=globalThis.localStorage}={}){
 validateOffice(members,zones);
 const key='agentoffice:v2:workspace:'+userId,settingsKey='agentoffice:v2:settings:'+userId;
 const read=k=>{try{return JSON.parse(storage?.getItem(k)||'null')}catch{return null}};
 const valid=t=>t&&typeof t.id==='string'&&typeof t.title==='string'&&t.title.length<=160&&members.some(m=>m.id===t.owner)&&STATUSES.includes(t.status);
 const saved=read(key),old=saved?null:read('agentoffice:v1.3:workspace:'+userId);
 const raw=saved?.tasks||old?.tasks, tasks=Array.isArray(raw)?raw.filter(valid):[];
 const prefs=read(settingsKey)||{};
 const store=createStore({members,zones,tasks,sprint:{id:'sprint-1'},events:[],announcements:[],selectedMemberId:null,selectedZoneId:null,cameraMode:'3d',demoRunning:true,settings:{sound:prefs.sound===true,alerts:prefs.alerts===true,readAloud:prefs.readAloud===true}});
 let failed=false;
 const persist=()=>{try{storage?.setItem(key,JSON.stringify({tasks:store.get().tasks}));storage?.setItem(settingsKey,JSON.stringify(store.get().settings));failed=false}catch{failed=true}};
 return {...store,get storageFailed(){return failed},
 setCameraMode:mode=>store.set({cameraMode:mode==='map'?'map':'3d'}),
 selectMember:id=>store.set({selectedMemberId:members.some(m=>m.id===id)?id:null}),
 selectZone:id=>store.set({selectedZoneId:zones.some(z=>z.id===id)?id:null}),
 toggleDemo:()=>store.set(s=>({demoRunning:!s.demoRunning})),
 toggleSetting(key){if(!['sound','alerts','readAloud'].includes(key))return;store.set(s=>({settings:{...s.settings,[key]:!s.settings[key]}}));persist()},
 addTask(title,owner){title=String(title).trim();if(!title||title.length>160||!members.some(m=>m.id===owner))return false;
 store.set(s=>({tasks:[...s.tasks,{id:globalThis.crypto.randomUUID(),title,owner,status:'Backlog'}]}));persist();return true},
 updateTask(id,status){if(!STATUSES.includes(status))return;store.set(s=>({tasks:s.tasks.map(t=>t.id===id?{...t,status}:t)}));persist()},
 record(event){store.set(s=>({events:[event,...s.events].slice(0,30),announcements:event.type==='announcement:new'?[event,...s.announcements].slice(0,8):s.announcements}))}
 };
}
