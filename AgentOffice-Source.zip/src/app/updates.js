import { icon } from '../icons.js';
import { esc } from './util.js';

// Desktop auto-update UI: status banner and the manual "check for updates" button.
// Behavior is carried over unchanged from the previous interface.
export function mountUpdates({ desktop, button, banner, showToast }) {
  let last = null;

  function display(st) {
    last = st;
    if (!banner) return;
    const visible = ['checking', 'downloading', 'available', 'ready', 'error'].includes(st.state);
    banner.hidden = !visible;
    if (!visible) return;
    const pct = st.percent && st.state === 'downloading' ? ` (${st.percent}%)` : '';
    banner.innerHTML = `<div><strong>${esc(st.state === 'ready' ? 'Update ready' : st.state === 'error' ? 'Update check failed' : 'App update')}</strong><p>${esc(st.message || 'Checking…')}${esc(pct)}</p></div>${st.state === 'ready' ? '<button id="install-update" class="btn btn-primary">Restart and install</button>' : `<button class="icon-button" id="dismiss-update" aria-label="Dismiss update notification">${icon('x', 17)}</button>`}`;
    banner.querySelector('#install-update')?.addEventListener('click', () => desktop?.installUpdate?.());
    banner.querySelector('#dismiss-update')?.addEventListener('click', () => { banner.hidden = true; });
  }

  async function check() {
    if (!desktop?.checkUpdates) return showToast('Automatic updates are available in the installed Windows app.');
    try {
      const status = await desktop.checkUpdates();
      display(status || { state: 'checking', message: 'Checking for updates…' });
      if (status?.state === 'current') showToast(status.message);
    } catch (err) {
      showToast(`Cannot check updates: ${err?.message || 'Unknown error'}`);
    }
  }

  button?.addEventListener('click', check);
  const stop = desktop?.onUpdateStatus ? desktop.onUpdateStatus(display) : null;
  if (desktop?.updateStatus) desktop.updateStatus().then(st => { if (st) display(st); }).catch(() => {});
  return () => { stop?.(); button?.removeEventListener('click', check); };
}
