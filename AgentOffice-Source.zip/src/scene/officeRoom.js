import * as T from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
export const PALETTE={floor:'#e4d1ac',wood:'#a88b68',wall:'#dedbd2',desk:'#343f3e',metal:'#253a37',orange:'#d6734e',leaf:'#47775a',glass:'#bad5d6',teal:'#b7d4c9',blue:'#b4cad5',red:'#d8b1a1',white:'#fffefa'};
// Static primitives are batched by geometry and material, including all desks and lamps.
export function buildOffice(scene,members,zones){
 const css=getComputedStyle(document.documentElement);
 for(const [key,token] of Object.entries({floor:'floor',wood:'wood',wall:'wall',desk:'desk',metal:'metal',orange:'terracotta',leaf:'leaf',glass:'glass',teal:'zone-teal',blue:'zone-blue',red:'zone-red',white:'paper'}))PALETTE[key]=css.getPropertyValue('--ao-'+token).trim()||PALETTE[key];
 const buckets=new Map(),materials=new Map(),geometries={box:new T.BoxGeometry(1,1,1),cylinder:new T.CylinderGeometry(.5,.5,1,12)};
 const group=new T.Group();scene.add(group);
 function put(shape,color,pos,scale,rotation=0){
  const key=shape+color;
  if(!buckets.has(key))buckets.set(key,{shape,color,matrices:[]});
  const object=new T.Object3D();object.position.set(...pos);object.scale.set(...scale);object.rotation.y=rotation;object.updateMatrix();buckets.get(key).matrices.push(object.matrix);
 }
 const box=(c,p,s,r)=>put('box',c,p,s,r);
 const cylinder=(c,p,s)=>put('cylinder',c,p,s);
 box(PALETTE.floor,[0,-.18,0],[29,.35,21]);
 // Alternating wood boards retain an offline, texture-free material.
 for(let x=-14;x<14;x+=1.4)box(PALETTE.wood,[x,.005,0],[.018,.012,20.9]);
 box(PALETTE.wall,[0,2.3,-10.5],[29,4.6,.25]);
 box(PALETTE.wall,[-14.5,1.1,0],[.25,2.2,21]);
 for(let x=-13;x<14;x+=2.8){
  box(PALETTE.metal,[x,2.6,-10.28],[.08,4.6,.08]);
  box(PALETTE.glass,[x+1.3,2.6,-10.35],[2.5,3.5,.04]);
 }
 box(PALETTE.metal,[0,4.7,-10.28],[29,.1,.12]);
 for(const z of zones){const b=z.bounds;box(PALETTE[z.color],[b.x,.025,b.z],[b.width,.04,b.depth])}
 for(const m of members){
  const {x,z}=m.desk;
  box(PALETTE.desk,[x,1.35,z],[2.6,.12,1.4]);
  for(const dx of [-1.1,1.1])for(const dz of [-.5,.5])box(PALETTE.metal,[x+dx,.65,z+dz],[.09,1.3,.09]);
  box(PALETTE.metal,[x,1.45,z],[.85,.04,.6]);
  box(PALETTE.metal,[x,1.76,z-.25],[.9,.58,.05]);
  box(PALETTE.blue,[x,1.76,z-.215],[.78,.46,.012]);
  cylinder(PALETTE.orange,[x+.95,1.45,z-.3],[.28,.12,.28]);
  box(PALETTE.orange,[x+.95,1.78,z-.3],[.045,.65,.045]);
  cylinder(PALETTE.orange,[x+.95,2.1,z-.3],[.42,.22,.42]);
  cylinder(PALETTE.white,[x-.96,1.53,z-.35],[.3,.3,.3]);
  for(let i=0;i<3;i++)box(PALETTE.leaf,[x-.96+(i-1)*.1,1.8+i*.04,z-.35],[.09,.42,.17],i);
  box(PALETTE.desk,[x,.65,z+1.35],[.85,.16,.8]);
  box(PALETTE.desk,[x,1.1,z+1.72],[.85,.9,.12]);
  cylinder(PALETTE.metal,[x,.3,z+1.35],[.12,.6,.12]);
  for(const dx of [-.4,.4])box(PALETTE.metal,[x+dx,.08,z+1.35],[.65,.08,.08]);
 }
 // Shared meeting room, glass partition, lounge and ping-pong.
 box(PALETTE.wood,[8,1.25,-4],[4,.18,2.5]);
 for(const x of [6.5,9.5])for(const z of [-5.8,-2.2]){
  box(PALETTE.desk,[x,.65,z],[.9,.15,.8]);box(PALETTE.metal,[x,.3,z],[.14,.6,.14]);
  box(PALETTE.desk,[x,1.1,z+(z<-4?-.4:.4)],[.9,.85,.1]);
 }
 box(PALETTE.glass,[1,1.7,-5],[.07,3.4,7]);
 box(PALETTE.metal,[1,3.4,-5],[.08,.06,7]);
 box(PALETTE.desk,[10,.6,7],[4,1.1,1.4]);box(PALETTE.wood,[10,1.2,7.55],[4,.6,.2]);
 box(PALETTE.white,[5,1.1,6],[3,.12,1.7]);box(PALETTE.teal,[5,1.18,6],[2.95,.035,1.65]);
 box(PALETTE.white,[5,1.36,6],[.04,.36,1.8]);
 for(const x of [4,6])box(PALETTE.metal,[x,.55,6],[.09,1.1,.09]);
 cylinder(PALETTE.wood,[10,1.15,3],[1.7,.12,1.7]);cylinder(PALETTE.metal,[10,.55,3],[.15,1.1,.15]);
 for(const x of [-10,-5,4,9]){
  box(PALETTE.metal,[x,4.2,0],[.025,1.3,.025]);cylinder(PALETTE.orange,[x,3.5,0],[1,.28,1]);
 }
 for(const batch of buckets.values()){
  if(!materials.has(batch.color))materials.set(batch.color,new T.MeshStandardMaterial({color:batch.color,roughness:.78}));
  const mesh=new T.InstancedMesh(geometries[batch.shape],materials.get(batch.color),batch.matrices.length);
  batch.matrices.forEach((matrix,i)=>mesh.setMatrixAt(i,matrix));mesh.castShadow=batch.color!==PALETTE.glass;mesh.receiveShadow=true;group.add(mesh);
 }
 const glass=materials.get(PALETTE.glass);glass.transparent=true;glass.opacity=.2;glass.depthWrite=false;
 return {group,async replaceWithModel(url){
   if(!/^\.\/models\/[a-zA-Z0-9_./-]+\.glb$/.test(url)||url.includes('..'))throw Error('Expected bundled GLB');
   const model=await new GLTFLoader().loadAsync(url);group.visible=false;scene.add(model.scene);return model;
 }};
}
