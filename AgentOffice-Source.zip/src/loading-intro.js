import screen from './loading-intro.html?raw';

// Runs after successful authentication; the local animation has no network dependencies.
export function mountLoadingIntro({onComplete}) {
  const root=document.querySelector('#app');
  const frame=document.createElement('iframe');
  frame.id='agentoffice-loading-intro';
  frame.title='AgentOffice — Preparing workspace';
  frame.setAttribute('sandbox','allow-scripts');
  frame.style.cssText='display:block;width:100%;height:100dvh;border:0;background:#151618';
  let done=false;
  let timer;
  const finish=()=>{
    if(done)return;
    done=true;
    clearTimeout(timer);
    window.removeEventListener('message',receive);
    if(frame.parentNode===root)onComplete();
  };
  function receive(event){
    if(event.source===frame.contentWindow && event.origin==='null' && event.data==='agentoffice:intro-complete')finish();
  }
  window.addEventListener('message',receive);
  // Fail open to the workspace if animation rendering is unavailable or stalled.
  timer=setTimeout(finish,5500);
  frame.srcdoc=screen;
  root.replaceChildren(frame);
}
