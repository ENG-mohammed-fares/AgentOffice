'use strict';
const {app, BrowserWindow, ipcMain} = require('electron');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname,'..');
const profile = fs.mkdtempSync(path.join(os.tmpdir(),'agentoffice-auth-check-'));
app.setPath('userData',profile);
app.disableHardwareAcceleration();
let checkpoint='app startup';
const log = label => { checkpoint=label; console.log('[auth-smoke] '+label); };
log('waiting for Electron app ready');
// A test harness must fail visibly even if an Electron IPC promise never settles.
const watchdog=setTimeout(()=>{console.error('[auth-smoke] stalled at '+checkpoint);app.exit(1)},180000);
app.whenReady().then(async () => {
  log('Electron app ready');
  // This fixture is outside the packaged application. Mail and Google are simulated here.
  let issued=false;
  require('../electron/auth.cjs').registerAuth(ipcMain,{
    configured:true,async sendCode(email){assert.equal(email,'qa@example.test');issued=true},
    async verifyCode(email,code){if(!issued||email!=='qa@example.test'||code!=='123456') throw Error('Invalid or expired code');issued=false},
    async google(){return {id:'google:test',name:'Google Tester',email:'other@example.test',guest:false}},
    async github(){return {id:'github:test',name:'GitHub Tester',email:'dev@example.test',guest:false}},
    cancelGoogle(){}
  });
  // Deliberately use a fixture version different from the build to catch hard-coded labels.
  ipcMain.handle('agentoffice:version',()=>({version:'9.8.7'}));
  ipcMain.handle('agentoffice:update-status',()=>({state:'idle',message:'Ready'}));
  const win = new BrowserWindow({show:false,width:1100,height:700,webPreferences:{
    preload:path.join(root,'electron','preload.cjs'),sandbox:true,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false
  }});
  win.webContents.on('render-process-gone',(_event,details)=>{console.error('[auth-smoke] renderer gone',details.reason);app.exit(1)});
  const bounded = async (promise,label,ms=15000) => {
    let deadline;
    try { return await Promise.race([promise,new Promise((_,reject)=>{deadline=setTimeout(()=>reject(Error('Timed out: '+label+' at '+checkpoint)),ms)})]); }
    finally { clearTimeout(deadline); }
  };
  const read = code => bounded(win.webContents.executeJavaScript(code),'renderer evaluation');
  const run = code => read('(()=>{const d=document.querySelector("iframe").contentDocument;const el=id=>d.getElementById(id);'+code+'})()');
  async function until(code,label) {
    log('checking '+label);
    const start = Date.now();
    while (!(await read(code))) {
      if (Date.now()-start>20000) {
        const state=await read('JSON.stringify({motion:matchMedia("(prefers-reduced-motion: reduce)").matches,mode:document.querySelector("#agentoffice-loading-intro")?.dataset.mode,phase:document.querySelector("#agentoffice-loading-intro")?.dataset.phase,inert:document.querySelector("#app")?.inert,login:!!document.querySelector("#app iframe")?.contentDocument?.getElementById("download")?.hidden})');
        throw Error('Timed out: '+label+'; state='+state);
      }
      await new Promise(resolve=>setTimeout(resolve,50));
    }
    log('passed '+label);
  }
  const authReady = () => until('!document.querySelector("#agentoffice-loading-intro") && document.querySelector("#app iframe")?.contentDocument?.getElementById("download")?.hidden','desktop login');
  const workspace = async () => {
    await until('Boolean(document.querySelector("#agentoffice-loading-intro"))','post-sign-in intro');
    assert.equal(await read('Boolean(document.querySelector("#sign-out"))'),false,'workspace must not precede intro');
    assert.equal(await read('document.querySelector("#agentoffice-loading-intro").getAttribute("sandbox")'),'allow-scripts');
    const start=Date.now();
    // Reject spoofed completion messages from the parent window.
    await read('window.postMessage("agentoffice:intro-complete","*")');
    await new Promise(resolve=>setTimeout(resolve,250));
    assert.equal(await read('Boolean(document.querySelector("#agentoffice-loading-intro"))'),true);
    await until('Boolean(document.querySelector("#sign-out"))','workspace after intro');
    assert.ok(Date.now()-start>=2500,'intro should play for about three seconds');
    assert.equal(await read('Boolean(document.querySelector("#agentoffice-loading-intro"))'),false,'intro must be removed');
  };
  const transition = mode => until('document.querySelector("#agentoffice-loading-intro")?.dataset.mode === '+JSON.stringify(mode),mode+' intro');
  // Observe the real DOM phase changes rather than polling a 480 ms animation
  // or blocking on a DevTools command before the first navigation.
  const observeLogin = () => read(`(()=>{
    window.__authSmokeObserver?.disconnect();
    window.__authSmokePhases=[];
    function record(frame,phase){
      if(!frame||frame.id!=='agentoffice-loading-intro')return;
      let login=false;
      try{login=!!document.querySelector('#app iframe')?.contentDocument?.getElementById('download')?.hidden}catch{}
      window.__authSmokePhases.push({mode:frame.dataset.mode,phase,inert:document.querySelector('#app').inert,login});
    }
    const observer=new MutationObserver(records=>{
      for(const item of records){
        if(item.type==='attributes')record(item.target,item.target.dataset.phase);
        else for(const node of item.addedNodes)if(node.nodeType===1)record(node,node.dataset?.phase);
      }
    });
    observer.observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['data-phase']});
    window.__authSmokeObserver=observer;
    const frame=document.querySelector('#agentoffice-loading-intro');
    if(frame)record(frame,frame.dataset.phase);
    return matchMedia('(prefers-reduced-motion: reduce)').matches;
  })()`);
  async function loginTransition(mode,reduced){
    await transition(mode);
    assert.equal(await read('document.querySelector("#app").inert'),true,'login blocked during '+mode+' intro');
    await authReady();
    assert.equal(await read('document.querySelector("#app").inert'),false,'login unlocked after '+mode);
    const phases=await read('window.__authSmokePhases');
    console.log('[auth-smoke] '+mode+' phases '+JSON.stringify(phases)+' reducedMotion='+reduced);
    assert.ok(phases.some(p=>p.mode===mode&&p.phase==='preparing'),mode+' destination preparation observed');
    if(reduced){
      assert.ok(!phases.some(p=>p.mode===mode&&p.phase==='revealing'),mode+' respects reduced motion');
    }else{
      assert.ok(phases.some(p=>p.mode===mode&&p.phase==='revealing'&&p.inert&&p.login),mode+' crossfade displays prepared login while interaction is blocked');
    }
  }
  const logout = async () => {
    const reduced=await observeLogin();
    await read('document.querySelector("#sign-out").click()');
    await loginTransition('logout',reduced);
  };
  log('loading built application');
  await bounded(win.loadFile(path.join(root,'dist','index.html')),'load application',30000);
  const reduced=await observeLogin();
  await loginTransition('startup',reduced);
  await until('document.querySelector("iframe")?.contentDocument?.getElementById("installedVersion")?.textContent === "9.8.7"','runtime installed version');
  assert.equal(await run('return el("installedVersionLabel").textContent.trim()'),'Version');
  await run('el("language").click();el("theme").click();el("signupTab").click()');
  assert.equal(await run('return d.documentElement.dir'), 'rtl');
  assert.equal(await run('return el("installedVersionLabel").textContent.trim()'),'الإصدار');
  assert.equal(await run('return el("installedVersion").textContent'),'9.8.7');
  assert.equal(await run('return d.documentElement.dataset.theme'), 'light');
  await run('el("name").value="Test User";el("email").value="qa@example.test";el("password").value="testing-10";el("confirm").value="different";el("authForm").requestSubmit()');
  assert.equal(await run('return el("confirm").getAttribute("aria-invalid")'),'true');
  await run('el("confirm").value=el("password").value;el("authForm").requestSubmit()');
  await workspace(); await logout();
  assert.equal(await run('return d.documentElement.lang'),'ar');
  await until('document.querySelector("iframe")?.contentDocument?.getElementById("installedVersion")?.textContent === "9.8.7"','version after logout');
  await run('el("email").value="qa@example.test";el("password").value="wrong-guess";el("authForm").requestSubmit()');
  await until('document.querySelector("iframe")?.contentDocument.querySelector("#formStatus.error")','rejected credentials');
  assert.equal(await read('Boolean(document.querySelector("#agentoffice-loading-intro"))'),false);
  await run('el("password").value="testing-10";d.querySelector(".remember input").checked=true;el("authForm").requestSubmit()');
  await workspace(); await logout();
  assert.equal(await run('return el("email").value'),'qa@example.test');
  await run('el("forgot").click();el("resetForm").requestSubmit()');
  await until('document.querySelector("iframe").contentDocument.querySelector("#resetCodeRow").hidden===false','email sent');
  await run('el("resetCode").value="111111";el("resetForm").requestSubmit()');
  await until('document.querySelector("iframe").contentDocument.querySelector("#resetStatus.error")','invalid OTP rejected');
  await run('el("resetCode").value="123456";el("resetForm").requestSubmit()');
  await until('document.querySelector("iframe").contentDocument.querySelector("#resetPasswordRow").hidden===false','verified OTP');
  const passwordReduced=await observeLogin();
  await run('el("resetNew").value=el("resetConfirm").value="replacement-secret";el("resetForm").requestSubmit()');
  await loginTransition('password',passwordReduced);
  assert.equal(await run('return el("email").value'),'qa@example.test');
  await until('document.querySelector("iframe")?.contentDocument?.querySelector("#recovery")?.hidden','password changed');
  await run('el("password").value="testing-10";el("authForm").requestSubmit()');
  await until('document.querySelector("iframe").contentDocument.querySelector("#formStatus.error")','old password rejected');
  await run('el("password").value="replacement-secret";el("authForm").requestSubmit()');
  await workspace();await logout();
  await run('el("google").click()');await workspace();
  assert.equal(await read('document.querySelector(".rail-person strong").textContent'),'Google Tester');
  await logout();
  await run('el("github").click()');await workspace();
  assert.equal(await read('document.querySelector(".rail-person strong").textContent'),'GitHub Tester');
  await logout();
  await run('el("guest").click()'); await workspace();
  assert.equal(await read('document.querySelector(".rail-person strong").textContent'),'Guest workspace');
  console.log('Verified reset UI including old password rejection, Google workspace entry with fixture provider, local accounts, guest, Arabic and theme on Windows.');
  clearTimeout(watchdog);
  app.exit(0);
}).catch(err=>{clearTimeout(watchdog);console.error('[auth-smoke] failed at '+checkpoint,err);app.exit(1)});
