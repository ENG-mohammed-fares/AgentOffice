import './tokens.css';
import './style.css';
import { mountAuth } from './auth.js';
import { mountApp } from './app/mountApp.js';

const enter = user => mountApp(user, { onSignOut: () => mountAuth({ onAuthenticated: enter }) });
const showLogin = () => mountAuth({ onAuthenticated: enter });

// Brief splash while the saved session is checked, then the sign-in intro or the app.
document.querySelector('#app').innerHTML = '<div class="boot-splash"><img src="./icon.png" alt="" width="72" height="72"></div>';

const desktop = window.agentOfficeDesktop;
if (desktop?.auth?.current) {
  desktop.auth.current().then(user => (user ? enter(user) : showLogin())).catch(showLogin);
} else {
  showLogin();
}
