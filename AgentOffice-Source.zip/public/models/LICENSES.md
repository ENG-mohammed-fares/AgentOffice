# Bundled office assets

Furniture and avatars are generated in Three.js from geometric primitives.
No third-party models are bundled. To replace an asset, add a reviewed GLB here
and record its author, original URL, license and retrieval date in this file.

The scene exposes replaceWithModel for the office and attachModel for avatars.
Avatar animation clips can be named idle, working, talking and walking.
