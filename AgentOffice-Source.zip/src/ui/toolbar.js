import {esc} from '../app/util.js';
import {localName} from '../data/labels.js';
export function mountToolbar(host,store,{lang,labels:l}){
 const render=()=>{const s=store.get();
 host.innerHTML=`<div class="toolbar" role="toolbar" aria-label="${esc(l.office)}"><button class="tb-btn" data-whole>${l.whole}</button>${s.zones.map(z=>`<button class="tb-btn" aria-pressed="${s.selectedZoneId===z.id}" data-zone="${esc(z.id)}">${esc(localName(z,lang))}</button>`).join('')}<button class="tb-btn" data-view aria-pressed="${s.cameraMode==='map'}">${s.cameraMode==='map'?l.three:l.map}</button>${['sound','alerts','readAloud'].map(k=>`<button class="tb-btn" data-toggle="${k}" aria-pressed="${s.settings[k]}">${l[k]}</button>`).join('')}<button class="tb-btn" data-demo aria-pressed="${s.demoRunning}">${s.demoRunning?l.pause:l.resume}</button></div>`};
 const click=e=>{const b=e.target.closest('button');if(!b)return;if(b.hasAttribute('data-whole')){store.selectMember(null);store.selectZone(null)}if(b.dataset.zone){store.selectMember(null);store.selectZone(b.dataset.zone)}if(b.hasAttribute('data-view'))store.setCameraMode(store.get().cameraMode==='map'?'3d':'map');if(b.dataset.toggle)store.toggleSetting(b.dataset.toggle);if(b.hasAttribute('data-demo'))store.toggleDemo()};
 host.addEventListener('click',click);const off=store.subscribe(render);render();
 return()=>{off();host.removeEventListener('click',click)};
}
