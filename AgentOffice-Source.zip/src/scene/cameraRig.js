import * as T from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
export function createCameraRig(element,reduced=false){
 const perspective=new T.PerspectiveCamera(44,1,.1,180),orthographic=new T.OrthographicCamera(-20,20,14,-14,.1,180);
 perspective.position.set(25,23,29);const target=new T.Vector3();
 const controls=new OrbitControls(perspective,element);
 controls.enableDamping=true;controls.dampingFactor=.09;controls.minDistance=7;controls.maxDistance=58;controls.maxPolarAngle=Math.PI*.46;controls.minPolarAngle=.12;controls.enablePan=true;
 let mode='3d',active=perspective,tween=null;
 const move=(position,point)=>{tween={start:performance.now(),from:perspective.position.clone(),to:position,fromTarget:controls.target.clone(),target:point};if(reduced){perspective.position.copy(position);controls.target.copy(point);tween=null} };
 controls.addEventListener('start',()=>{tween=null});
 return {get camera(){return active},controls,
 setMode(next){if(next===mode)return;mode=next;if(mode==='map'){move(new T.Vector3(0,37,.1),new T.Vector3());}else{active=perspective;move(new T.Vector3(25,23,29),new T.Vector3())}controls.enabled=mode!=='map'},
 focus(point,wide=false){if(mode==='map'){orthographic.position.set(point.x,45,point.z+.01);orthographic.lookAt(point.x,0,point.z);return}move(new T.Vector3(point.x+(wide?14:6),wide?19:8,point.z+(wide?17:8)),new T.Vector3(point.x,0,point.z))},
 update(now){
  if(tween){const f=reduced?1:Math.min(1,(now-tween.start)/650),k=f*f*(3-2*f);perspective.position.lerpVectors(tween.from,tween.to,k);controls.target.lerpVectors(tween.fromTarget,tween.target,k);if(f===1)tween=null}
  controls.target.x=T.MathUtils.clamp(controls.target.x,-12,12);controls.target.z=T.MathUtils.clamp(controls.target.z,-9,9);controls.target.y=0;controls.update();
  if(mode==='map'&&!tween){active=orthographic;orthographic.position.set(controls.target.x,45,controls.target.z+.01);orthographic.lookAt(controls.target.x,0,controls.target.z)}
 },
 resize(w,h){const aspect=w/Math.max(1,h);perspective.aspect=aspect;perspective.updateProjectionMatrix();orthographic.left=-14*aspect;orthographic.right=14*aspect;orthographic.top=14;orthographic.bottom=-14;orthographic.updateProjectionMatrix()},
 dispose(){controls.dispose()}
 };
}
