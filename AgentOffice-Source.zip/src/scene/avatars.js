import * as T from 'three';
import {CSS2DObject} from 'three/addons/renderers/CSS2DRenderer.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {clone} from 'three/addons/utils/SkeletonUtils.js';
import {memberState} from '../data/schema.js';
import {localName} from '../data/labels.js';
import {PALETTE} from './officeRoom.js';
export function createAvatars(scene,members,{lang,labels}){
 const picks=[],items=new Map(),geo=new T.BoxGeometry(1,1,1);
 for(const [index,m] of members.entries()){
  const group=new T.Group();group.position.set(m.desk.x,0,m.desk.z+1.15);scene.add(group);
  const body=new T.Group();group.add(body);
  const part=(color,p,s)=>{const mesh=new T.Mesh(geo,new T.MeshStandardMaterial({color,roughness:.8}));mesh.position.set(...p);mesh.scale.set(...s);mesh.castShadow=true;body.add(mesh);mesh.userData.memberId=m.id;picks.push(mesh);return mesh};
  const a=m.appearance,shirt=a.shirt,skin=a.skin,h=a.height;
  part(shirt,[0,1.15*h,0],[.58,.67,.35]);
  part(skin,[0,1.8*h,0],[.46,.48,.42]);part(PALETTE.metal,[0,2.03*h,0],[.48,.12,.45]);
  for(const x of [-.28,.28])part(PALETTE.desk,[x,.57,.2],[.2,.48,.33]);
  const hands=[-.37,.37].map(x=>part(skin,[x,1.27,-.3],[.16,.17,.4]));
  const circle=new T.Mesh(new T.RingGeometry(.55,.65,32),new T.MeshBasicMaterial({color:PALETTE.orange,side:T.DoubleSide}));
  circle.rotation.x=-Math.PI/2;circle.position.y=.08;circle.visible=false;group.add(circle);
  const marker=new T.Mesh(new T.SphereGeometry(.3,12,8),new T.MeshBasicMaterial({color:shirt}));marker.position.y=.3;marker.userData.memberId=m.id;group.add(marker);picks.push(marker);marker.visible=false;
  const el=document.createElement('div');el.className='member-label';
  const dot=document.createElement('i'),name=document.createElement('strong'),description=document.createElement('span'),speech=document.createElement('small');
  name.textContent=localName(m,lang);description.textContent=lang==='ar'?m.descriptionAr:m.description;el.append(dot,name,description,speech);
  const label=new CSS2DObject(el);label.position.y=2.6;group.add(label);
  items.set(m.id,{m,group,body,hands,label,el,speech,circle,marker,state:'idle',until:0,move:null,index,mixer:null});
 }
 return {picks,items,hover(id){for(const [key,a] of items)a.circle.visible=key===id},
 event(e){const a=items.get(e.memberId);if(!a)return;
  if(e.type==='member:move'){a.move={start:performance.now(),from:a.group.position.clone(),to:new T.Vector3(e.target.x,0,e.target.z),duration:(e.duration||8)*1000};a.state='walking'}
  else if(e.type==='member:status'){a.state=e.status;a.until=performance.now()+(e.duration||5)*1000}
 },
 async attachModel(id,url){
  if(!/^\.\/models\/[a-zA-Z0-9_/-]+\.glb$/.test(url)||url.includes('..'))throw Error('Expected bundled GLB');
  const a=items.get(id);if(!a)return;const gltf=await new GLTFLoader().loadAsync(url),model=clone(gltf.scene);
  a.body.visible=false;a.group.add(model);a.mixer=new T.AnimationMixer(model);
  a.clips=Object.fromEntries(gltf.animations.map(clip=>[clip.name,a.mixer.clipAction(clip)]));
 },
 update(time,dt,state,camera,map,reduced){
  const used=[];
  for(const a of items.values()){
   if(a.move){
    let f=Math.min(1,(time-a.move.start)/a.move.duration);if(reduced)f=1;
    // Straight out to the central aisle, then to the destination, and back.
    const t=f<.5?f*2:(1-f)*2,from=a.move.from,to=a.move.to;
    const aisle=new T.Vector3(0,0,from.z);
    if(t<.35)a.group.position.lerpVectors(from,aisle,t/.35);
    else if(t<.7)a.group.position.lerpVectors(aisle,new T.Vector3(0,0,to.z),(t-.35)/.35);
    else a.group.position.lerpVectors(new T.Vector3(0,0,to.z),to,(t-.7)/.3);
    a.body.position.y=reduced?0:Math.abs(Math.sin(time*.009))*.07;
    if(f===1){a.group.position.copy(from);a.move=null;a.body.position.y=0;a.state=memberState(state.tasks,a.m.id)}
   }else if(time>a.until)a.state=memberState(state.tasks,a.m.id);
   a.hands.forEach((hand,i)=>hand.rotation.x=!reduced&&a.state==='working'?Math.sin(time*.012+i)*.13:0);
   a.speech.textContent=a.state==='talking'?labels.talking:'';
   a.el.dataset.status=a.state;a.el.title=labels[a.state];
   a.body.visible=!map;a.marker.visible=map;a.label.position.y=map?.6:2.6;
   const selected=state.selectedMemberId===a.m.id;
   a.el.classList.toggle('selected',selected);a.mixer?.update(dt);
   if(a.clips&&a.lastState!==a.state){a.clips[a.lastState]?.fadeOut(.2);a.clips[a.state]?.reset().fadeIn(.2).play();a.lastState=a.state}
   const v=a.group.position.clone().project(camera),distance=camera.position.distanceTo(a.group.position);
   const x=v.x,y=v.y;
   const overlaps=used.some(p=>Math.abs(p.x-x)<.20&&Math.abs(p.y-y)<.13);
   a.el.style.opacity=v.z>1||v.z< -1||(!selected&&overlaps)?'0':String(map?1:Math.max(.6,1-distance/100));
   a.el.style.transform='scale('+Math.max(.8,1-distance/180)+')';
   if(!overlaps||selected)used.push({x,y});
  }
 }};
}
