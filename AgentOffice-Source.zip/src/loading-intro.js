import screen from './loading-intro.html?raw';

// Full-window animation is reserved for authentication lifecycle transitions.
const COPY={
  startup:['Starting AgentOffice','Preparing sign in','Ready'],
  signin:['Preparing workspace','Loading team','Ready'],
  logout:['Signing out','Returning to sign in','Signed out'],
  password:['Updating account','Returning to sign in','Password updated']
};
export function mountLoadingIntro({mode='signin',onComplete}) {
  const selected=Object.hasOwn(COPY,mode)?mode:'signin';
  const [first,second,final]=COPY[selected];
  const markup=screen.replace('Preparing workspace</span>',first+'</span>')
    .replace('Loading team</span>',second+'</span>')
    .replace('</svg>Ready</span>','</svg>'+final+'</span>');
  const root=document.querySelector('#app');
  const frame=document.createElement('iframe');
  frame.id='agentoffice-loading-intro';
  frame.dataset.mode=selected;
  frame.title='AgentOffice — '+first;
  frame.setAttribute('sandbox','allow-scripts');
  frame.style.cssText='display:block;width:100%;height:100dvh;border:0;background:#151618';
  let done=false;
  let timer;
  const finish=()=>{
    if(done)return;
    done=true;
    clearTimeout(timer);
    window.removeEventListener('message',receive);
    if(frame.parentNode===root)onComplete();
  };
  function receive(event){
    if(event.source===frame.contentWindow && event.origin==='null' && event.data==='agentoffice:intro-complete')finish();
  }
  window.addEventListener('message',receive);
  // Fail open to the workspace if animation rendering is unavailable or stalled.
  timer=setTimeout(finish,5500);
  frame.srcdoc=markup;
  root.replaceChildren(frame);
}
